package com.example.Addition;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AdditionApplicationTests {

	@Test
	void contextLoads() {
	}

}
